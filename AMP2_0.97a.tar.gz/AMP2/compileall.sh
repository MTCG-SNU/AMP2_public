python -m compileall ./src/
